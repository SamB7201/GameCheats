﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using GameCheats.Data;
using GameCheats.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Logging;

namespace GameCheats.Controllers
{
    public class GcCheatsController : Controller
    {
        private readonly henryContext _context;
        private readonly ILogger<GcCheatsController> _logger;

        public GcCheatsController(henryContext context, ILogger<GcCheatsController> logger)
        {
            _context = context;
            _logger = logger;
        }

        // GET: GcCheats
        [Authorize]
        public async Task<IActionResult> Index(string searchString, string titleString, string cheatString)
        {
            var cheats = from c in _context.GcCheats
                         select c;

            if (!String.IsNullOrEmpty(searchString))
            {
                cheats = cheats.Where(c => c.Platform.Contains(searchString));
            }
            else if (!String.IsNullOrEmpty(titleString))
            {
                cheats = cheats.Where(g => g.Game.Contains(titleString));
                if (cheats.Count() == 0)
                {
                    _logger.LogWarning((EventId)404, "Could not find cheats for {GameTitle} - Title Search", titleString);
                }
            }
            else if (!String.IsNullOrEmpty(cheatString))
            {
                cheats = cheats.Where(g => g.Cheat.Contains(cheatString));
                if (cheats.Count() == 0)
                {
                    _logger.LogWarning((EventId)404, "Could not find cheats for {GameCheat} - Cheat Search", cheatString);
                }
            }

            return View(await cheats.AsNoTracking().ToListAsync());
        }

        // GET: GcCheats/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var gcCheats = await _context.GcCheats
                .FirstOrDefaultAsync(m => m.CheatId == id);
            if (gcCheats == null)
            {
                return NotFound();
            }

            return View(gcCheats);
        }

        // GET: GcCheats/Create
        public IActionResult Create()
        {
            ViewData["UserName"] = User.Identity.Name;
            return View();
        }

        // POST: GcCheats/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("CheatId,Game,Platform,Cheat,Steps,UserName")] GcCheats gcCheats)
        {
            if (ModelState.IsValid)
            {
                _context.Add(gcCheats);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(gcCheats);
        }

        // GET: GcCheats/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var gcCheats = await _context.GcCheats.FindAsync(id);
            if (gcCheats == null)
            {
                return NotFound();
            }
            ViewData["UserName"] = User.Identity.Name;
            return View(gcCheats);
        }

        // POST: GcCheats/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("CheatId,Game,Platform,Cheat,Steps")] GcCheats gcCheats)
        {
            if (id != gcCheats.CheatId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(gcCheats);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    _logger.Log(LogLevel.Error, (EventId)1500, "Model State is Not Valid");
                    if (!GcCheatsExists(gcCheats.CheatId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                _logger.Log(LogLevel.Information, "Model State is Valid");
                return RedirectToAction(nameof(Index));
            }
            return View(gcCheats);
        }

        // GET: GcCheats/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var gcCheats = await _context.GcCheats
                .FirstOrDefaultAsync(m => m.CheatId == id);
            if (gcCheats == null)
            {
                return NotFound();
            }

            return View(gcCheats);
        }

        // POST: GcCheats/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var gcCheats = await _context.GcCheats.FindAsync(id);
            _context.GcCheats.Remove(gcCheats);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool GcCheatsExists(int id)
        {
            return _context.GcCheats.Any(e => e.CheatId == id);
        }
    }
}
