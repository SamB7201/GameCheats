﻿using System;
using System.Collections.Generic;

namespace GameCheats.Models
{
    public partial class Author
    {
        public decimal AuthorNum { get; set; }
        public string AuthorLast { get; set; }
        public string AuthorFirst { get; set; }
    }
}
