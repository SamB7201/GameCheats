﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace GameCheats.Models
{
    public partial class henryContext : DbContext
    {
        public henryContext()
        {
        }

        public henryContext(DbContextOptions<henryContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Access> Access { get; set; }
        public virtual DbSet<Author> Author { get; set; }
        public virtual DbSet<Book> Book { get; set; }
        public virtual DbSet<GcCheats> GcCheats { get; set; }
        public virtual DbSet<TestAuth> TestAuth { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Access>(entity =>
            {
                entity.HasKey(e => e.UserId)
                    .HasName("PK__Access__CB9A1CDF0E38217E");

                entity.HasIndex(e => e.AccessLevel)
                    .HasName("UQ__Access__126932598A6F691C")
                    .IsUnique();

                entity.HasIndex(e => e.Password)
                    .HasName("UQ__Access__6E2DBEDE9FCED154")
                    .IsUnique();

                entity.HasIndex(e => e.Username)
                    .HasName("UQ__Access__F3DBC5720F479A89")
                    .IsUnique();

                entity.Property(e => e.UserId).HasColumnName("userID");

                entity.Property(e => e.AccessLevel)
                    .IsRequired()
                    .HasColumnName("accessLevel")
                    .HasMaxLength(30);

                entity.Property(e => e.Password)
                    .IsRequired()
                    .HasColumnName("password")
                    .HasMaxLength(50);

                entity.Property(e => e.Username)
                    .IsRequired()
                    .HasColumnName("username")
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<Author>(entity =>
            {
                entity.HasKey(e => e.AuthorNum)
                    .HasName("PK__Author__7E6BD29CAE9AEAD6");

                entity.Property(e => e.AuthorNum).HasColumnType("decimal(2, 0)");

                entity.Property(e => e.AuthorFirst)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.AuthorLast)
                    .HasMaxLength(12)
                    .IsUnicode(false)
                    .IsFixedLength();
            });

            modelBuilder.Entity<Book>(entity =>
            {
                entity.HasKey(e => e.BookCode)
                    .HasName("PK__Book__0A5FFCC6A8AB3ABD");

                entity.Property(e => e.BookCode)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.Paperback)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.PublisherCode)
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.Title)
                    .HasMaxLength(40)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.Type)
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .IsFixedLength();
            });

            modelBuilder.Entity<GcCheats>(entity =>
            {
                entity.HasKey(e => e.CheatId)
                    .HasName("PK__GC_Cheat__B6F3BC7039EA4366");

                entity.ToTable("GC_Cheats");

                entity.Property(e => e.CheatId).HasColumnName("cheatID");

                entity.Property(e => e.Cheat)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(e => e.Game)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(e => e.Platform)
                    .IsRequired()
                    .HasMaxLength(10);

                entity.Property(e => e.Steps)
                    .IsRequired()
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<TestAuth>(entity =>
            {
                entity.HasKey(e => e.AuthNum)
                    .HasName("PK__testAuth__69528A75DC3CAE91");

                entity.ToTable("testAuth");

                entity.Property(e => e.AuthNum)
                    .HasColumnName("authNum")
                    .ValueGeneratedNever();

                entity.Property(e => e.FName)
                    .IsRequired()
                    .HasColumnName("fName")
                    .HasMaxLength(30);

                entity.Property(e => e.LName)
                    .IsRequired()
                    .HasColumnName("lName")
                    .HasMaxLength(30);

                entity.Property(e => e.NetWorth)
                    .HasColumnName("netWorth")
                    .HasColumnType("decimal(8, 2)");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
