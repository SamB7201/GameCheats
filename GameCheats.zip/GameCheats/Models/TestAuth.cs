﻿using System;
using System.Collections.Generic;

namespace GameCheats.Models
{
    public partial class TestAuth
    {
        public int AuthNum { get; set; }
        public string FName { get; set; }
        public string LName { get; set; }
        public decimal NetWorth { get; set; }
    }
}
