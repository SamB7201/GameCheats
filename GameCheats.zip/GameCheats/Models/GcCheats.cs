﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace GameCheats.Models
{
    public partial class GcCheats
    {
        public int CheatId { get; set; }
        
        [Required]
        public string Game { get; set; }

        [Required]
        [RegularExpression("PC|Xbox One|Xbox 360|PS4|PS3|PS2", ErrorMessage = "Platforms must be PC, Xbox One, Xbox 360, PS4, PS3, or PS2")]
        public string Platform { get; set; }

        [Required]
        public string Cheat { get; set; }

        [Required]
        public string Steps { get; set; }
        public string UserName { get; set; }
    }
}
